Dies ist die Version der C/C++-Klausur, die am 17.09.2013 geschrieben wurde.
Der Inhalt dieses Ordners befand sich auf dem USB-Stick, der zu Beginn der
Klausur an die Kursteilnehmenden ausgeteilt wurde.

Bemerkung: Versehentlich wurde von Aufgabe 1 (c++) die Musterl�sung statt
der Rohversion ausgeteilt. Dies wurde w�hrend der Klausur festgestellt und
die Aufgabe wurde gestrichen.


Meine Einsch�tzung der Klausur:
Ich habe trotz des Wegfalls von 50 % der C++ Klausur die vollen 3,5 h
gebraucht, war dann aber auch mit allen Aufgaben fertig.