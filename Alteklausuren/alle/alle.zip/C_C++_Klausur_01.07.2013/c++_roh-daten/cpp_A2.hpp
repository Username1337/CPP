// Prüfung C, Sommer 2013, A.Voss@FH-Aachen.de

// todo: matse_name:   Nachname
// todo: matse_matrnr: 123456

#include <iostream>
#include <functional>

using namespace std;

// todo:
class PRNG_Base { };

// todo: 
// class LKG 

// todo: 
// class PRNG


