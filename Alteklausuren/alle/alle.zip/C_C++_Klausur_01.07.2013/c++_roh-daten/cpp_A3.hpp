// Prüfung C, Sommer 2013, A.Voss@FH-Aachen.de

// todo: matse_name:   Nachname
// todo: matse_matrnr: 123456

#include <iostream>
#include <vector>
#include <string>
#include <initializer_list>
#include <functional>
#include <thread>

using namespace std;

// todo:
class stringset { };
