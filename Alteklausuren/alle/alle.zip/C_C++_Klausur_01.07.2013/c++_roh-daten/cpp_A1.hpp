// Prüfung C, Sommer 2013, A.Voss@FH-Aachen.de

// todo: matse_name:   Nachname
// todo: matse_matrnr: 123456

#include <thread>

// todo:
unsigned int sum_factors_serial(unsigned int n)
{
    return (unsigned int)(-1);
}

// todo:
unsigned int sum_factors_parallel(unsigned int n)
{
    return (unsigned int)(-1);
}
