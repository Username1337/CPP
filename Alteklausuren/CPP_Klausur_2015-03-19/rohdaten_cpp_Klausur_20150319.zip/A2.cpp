#include <iostream>
#include <fstream>
#include <string>
#include <memory>
#include <sstream>
using namespace std;

const string matse_name   = "Vorname Nachname";
const string matse_matrnr = "123456";

class Verschluesselung {
public:
  Verschluesselung(string v) : verfahren(v) { }
  ~Verschluesselung() { }

  void verschluesseln() { };
  void entschluesseln() { klartext = "komisch komisch"; };

  void einlesen(/* ... */) {
  }

  string getVerfahren() {  return verfahren;  }
  string getChiffre()   {  return chiffre;    }
  string getKlartext()  {  return klartext;   }

  void setKlartext(string k) {
    klartext = k;
  }

protected:
  string verfahren;
  string chiffre;
  string klartext;
};


class RSA {
public:
  RSA() { };

  void verschluesseln() {
  }
  
  void entschluesseln() {
  }

  long long pow(int b, int exp) {
    long long result = 1;
    for (int i=0; i < exp; ++i)
      result *= b;
    return result;
  }

  void memory_test() {
    // Neues dynamisch angelegtes Objekt
    // Verschluesselung *v = new RSA();

    // Benutzung des Objektes
    // v->setKlartext("EIN_KLEINER_TEST");
    // v->verschluesseln();
  }

}; 


int main() 
{    
    if (matse_name=="Vorname Nachname" || matse_matrnr=="123456") {
        cout << "*** Sie müssen noch ihre Daten eintragen ***" << endl << endl;
        return EXIT_FAILURE;
    }

    cout << "--- Wintersemester 2014/15, Aufgabe A2" << endl;
    cout << "    Name: " << matse_name+", MatrNr: " << matse_matrnr << endl << endl;

    // a)
    {
    // Verschluesselung *v1 = new RSA();
    
    // string verfahren = v1->getVerfahren();

    // Verschluesselung *v2 = new RSA();
    // Verschluesselung *v3 = new RSA();

    // int c1 = Verschluesselung::counter;
    // delete v3;
    // int c2 = Verschluesselung::counter;

    // delete v2;
    // delete v1;
    // int c3 = Verschluesselung::counter;
    
    // cout << "a) " << ( verfahren == "RSA" &&
    //          c1 == 3 &&
    //          c2 == 2 &&
    //          c3 == 0 ) << endl;
    }
    
    // b)
    {
    // RSA rsa;
    // rsa.einlesen("geheim.txt");

    // string k = rsa.getChiffre();
    // int sum = 0;
    // for(char c : k) sum += (int)c;
    
    // cout << "b) " << (sum == 2225) << endl;
    }
    
    // c)
    {
    // Verschluesselung *v = new RSA();
    // v->einlesen("geheim.txt");
    // v->entschluesseln();

    // string k = v->getKlartext();
    // cout << "c) Klartext: " << k << endl;
    // int sum = 0;
    // for(char c : k)
    //     sum += (int)c;

    // v->setKlartext("HALLO_MATSE");
    // v->verschluesseln();
    // string ch = v->getChiffre();

    // v->setKlartext("");
    // v->entschluesseln();
    // string kl = v->getKlartext();
    // delete v;
    
    // cout << "c) " << (sum == 2108 && 
    //         ch  == "QALLIYSAN\\Z" &&
    //         kl  == "HALLO_MATSE") << endl;
    }
    
    // d)
    {
    // RSA *v = new RSA();
    // v->memory_test();
    // delete v;
    
    // cout << "d) " << (Verschluesselung::counter == 0) << endl;
    }
    
    return EXIT_SUCCESS;
}
