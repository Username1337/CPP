#include <iostream>
#include <vector>
#include <thread>
#include <mutex>
#include <initializer_list>
#include <algorithm>
#include <sstream>
using namespace std;

const string matse_name   = "Vorname Nachname";
const string matse_matrnr = "123456";

class SuchVektor {
public:
// ...
};

int main() 
{
    if (matse_name=="Vorname Nachname" || matse_matrnr=="123456") {
        cout << "*** Sie müssen noch ihre Daten eintragen ***" << endl << endl;
        return EXIT_FAILURE;
    }

    cout << "--- Wintersemester 2014/15, Aufgabe A1" << endl;
    cout << "    Name: " << matse_name+", MatrNr: " << matse_matrnr << endl << endl;

    // a)
    {
    // std::vector<float> *sv = new SuchVektor<float>();
    // delete sv;
    
    // cout << "a) 1" << endl; 
    }

    // b)
    {
    // SuchVektor<int>    sv1;
    // SuchVektor<int >   sv2({ 1, 2, 3, 4, 5 });
    // SuchVektor<double> sv3({ 1.0, 1.1, 1.2, 1.3 });
    
    // cout << "b) 1" << endl; 
    }
    
    // c)
    {
    // SuchVektor<int> sv({ 1, 2, 30 });
    // ostringstream os;
    // os << sv;
    
    // cout << "c) " << (os.str() == "[ 1 2 30 ]") << endl;
    }

    // d)
    {
    #define LAMBDA_EXPR xxx
    // SuchVektor<int> sv({ 1, 2, 3, 4 });
    // sv.fill(20, LAMBDA_EXPR);
    
    // bool b=true;
    // for (int n=0; n < (int)sv.size(); ++n)
    //    b &= (sv[(unsigned int)n] == (6*n)%13);
    // cout << "d) " << b << endl;
    }

    // e)
    {
    // SuchVektor<int> sv({0,6,12,5,11,4,10,3,9,2,8,1,7,0,6,12,5,11,4,10});
    // SuchVektor<unsigned int> erg = sv.search( 11 );
    
    // cout << "e) " << ( (erg.size() == 2) && 
    //          (erg[0] == 4 || erg[0] == 17) &&
    //          (erg[1] == 4 || erg[1] == 17) &&
    //          (erg[0] + erg[1] == 21) ) << endl;
    }

    // f)
    {
    // SuchVektor<double> sv1({ 1.0, 1.9, 2.0, 2.5, 3.4 });
    // SuchVektor<int>    sv2({ 10 });
    // sv2 = sv1;
    // ostringstream os;
    // os << sv2;
    
    // cout << "f) " << (os.str() == "[ 1 1 2 2 3 ]") << endl;
    }

    // g)
    {
    // SuchVektor<double> sv1({ 1.0, 1.9, 12.0, 2.5, 3.4 });
    // SuchVektor<int>    sv2({ 1, 2, 5, 23, 2, 1 });    
    // double max_double = sv1;
    // int    max_int    = sv2;
    
    // cout << "g) " << (max_double == 12.0 && max_int == 23) << endl;
    }

    // h)
    {
    // SuchVektor<int> v({ 1, 2, 5, 23, 2, 1 });

    // int n=3;
    // bool b3 = (n & v);
    // n=23;
    // bool b23 = (n & v);
    // n=5;
    // bool b5 = (n & v);

    // cout << "h) " << (!b3 && b23 && b5) << endl;
    }

    // I
    {
    #pragma GCC diagnostic ignored "-Wunused-variable"

    // SuchVektor<int> v({ 1, 2, 5, 23, 2, 1 });
    // SuchVektor<int>::value_type elem = v[3];

    // cout << "i) 1" << endl;
    }

    return EXIT_SUCCESS;
}
