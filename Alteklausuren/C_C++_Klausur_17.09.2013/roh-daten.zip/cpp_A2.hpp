// Prüfung C++, Herbst 2013, A.Voss@FH-Aachen.de

// todo: matse_name:   Nachname
// todo: matse_matrnr: 123456

#include <iostream>
#include <thread>
#include <vector>
#include <chrono>
#include <cstdlib>
#include <algorithm>
#include <sstream>
using namespace std;

// Konstanten, um A und B zu unterscheiden
enum { in_A = 1, in_B = 2 };

struct A {
    int g() { return in_A; }
    int n = in_A;
};

class B : public A {
public:
    B() { }
    
    bool f() { return true; }
    
    int g() { return in_B; }
    
    int h() { return 23; }
        
    friend ostream & operator<<(ostream & os, const B & c)
    {
        // os << c.h();     // (d)
        return os;
    }

    int n = in_B;
};

bool test_f()
{
    B b();
    // return b.f();        // (a)
    return false;
}

bool test_g()               // (c)
{
    A * p = new B();
    
    return (in_B==p->g());  // (b) 
}

bool test_h()               // (d)
{
    stringstream s;
    
    B b;
    s << b;
    
    return (s.str()=="23");
}

bool test_n() {
    B b;
    return (in_A==b.n);     // (e)
}

template <int n>
struct sum
{
    double s = 1.0/(double)(n)/(double)(n) + sum<n-1>().s;
}; 

bool test_s() {
    const double pi = 3.14159265358979323846264338327;
    const double exact = pi*pi/6.0;

    double s = 0.0; // = sum<10>().s;         // (f)
    // cout << s << " " << s-exact << endl;

    return fabs(s-exact)<1e-1;
}

