// Prüfung C++, Herbst 2013, A.Voss@FH-Aachen.de

#include "test.h"
#include "ident.h"

// Ihr code 
#include "cpp_A2.hpp"

int main()
{   
    StartTest("C++",2);

    AssertS("'call f'", test_f() );
    AssertS("'call g'", test_g() );
    AssertS("'call h'", test_h() );
    AssertS("'call n'", test_n() );
    AssertS("'call s'", test_s() );

    StopTest();
    
    return EXIT_SUCCESS;
}
