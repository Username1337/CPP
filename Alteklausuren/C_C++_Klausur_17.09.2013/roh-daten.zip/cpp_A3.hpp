// Prüfung C++, Herbst 2013, A.Voss@FH-Aachen.de

// todo: matse_name:   Nachname
// todo: matse_matrnr: 123456

#include <iostream>
#include <thread>
#include <vector>
#include <chrono>
#include <cstdlib>
#include <algorithm>
using namespace std;

bool sum(unsigned int number_threads)
{
    const double pi = 3.14159265358979323846264338327;
    const double exact = pi*pi/6.0;
    
    unsigned int n0 = 1, n1 = 1000001; 
    double s=0;

    // todo
    
    // cout << "sum=" << s << " " << fabs(s-exact) << endl;
    return fabs(s-exact)<1e-4;
}

