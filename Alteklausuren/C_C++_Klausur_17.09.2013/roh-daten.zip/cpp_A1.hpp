// Prüfung C++, Herbst 2013, A.Voss@FH-Aachen.de

// todo: matse_name:   Nachname
// todo: matse_matrnr: 123456

#include <iostream>
#include <thread>
#include <vector>
#include <chrono>
#include <cstdlib>
#include <algorithm>
#include <sstream>
using namespace std;
using namespace chrono;

// todo:

class set
{
    public:
    
        unsigned int hash_table_size_;
        std::vector<unsigned int> hash_table_;
        unsigned int elements;
        size_t size() const { return elements; }
        size_t max_size() const { return hash_table_size_; }
        
        // A1_a)
        set(unsigned int max_elements) 
        {

        }
        
        // A1_b) initializer liste

        
        // A1_c)
        bool contains(unsigned int n)
        {
            return false;
        }
        
        // d) + e)
        void set_value(unsigned int n)
        {

        }

        // f)
        void remove_value(unsigned int n)
        {

        }
        
        // g) operator +
        
        // h) Ausgabe-operator


};

bool test_ctor_contains()
{
    //set s1(5);
    //set s2(7,{1,2});

    bool rc = true;

    //rc &= (s1.size()==0) && (s1.max_size()==5);
    //rc &= (s2.size()==2) && (s2.max_size()==7);
    //rc &= s2.contains(1) && s2.contains(2) && (!s2.contains(3));

    return rc;
}

bool test_set_remove()
{
    set s(5);
    
    bool rc = true;
    
    rc &= (s.size()==0) && (s.max_size()==5);
    
    s.set_value(1);
    rc &= (s.size()==1);
    s.set_value(1);
    rc &= (s.size()==1);

    s.set_value(2);
    s.set_value(3);
    s.set_value(4);
    s.set_value(5);
    rc &= (s.size()==5);

    try
    {
        s.set_value(6);
        rc = false;
    }
    catch (...)
    {
        rc &= (s.size()==5);
    }
    
    s.remove_value(4);
    rc &= (s.size()==4);

    s.remove_value(4);
    rc &= (s.size()==4);

    s.remove_value(5);
    s.remove_value(3);
    s.remove_value(2);
    s.remove_value(1);
    rc &= (s.size()==0);

    return rc;
}

bool test_opplus()
{
    //set s1(3,{1,2,3});
    //set s2(5,{2,3,4,5});
    //set s3 = s1+s2;

    //return (s3.size()==5);
}

bool test_output()
{
    set m(7);
    stringstream s;
    
    m.set_value(23);
    m.set_value(14);
    //s << m;
    
    return (s.str()=="( 23 14 )") || (s.str()=="( 14 23 )");
}

bool test_speed()
{
    unsigned int numbers = 10000;
    unsigned int range = 100000;
    
    time_point<system_clock> start;
    double time1,time2;
    
    int n;

    vector<unsigned int> v1;
    v1.reserve(numbers);
    
    set v2(numbers);

    // starte Zeitmessung und fülle einfachen vector v1 mit (initialisierten) Zufallszahlen
    srand(0);
    start = system_clock::now();
    
    while (v1.size()<numbers)
    {
        n = rand() % range;
        if (find(v1.begin(),v1.end(),n)==v1.end())
            v1.push_back(n);
    }
    time1 = (double)(duration_cast<milliseconds>(system_clock::now()-start).count())/1000.0;

    cout << "      Zeit v1: " << time1 << endl;

    // starte zweite Zeitmessung und fülle set v2 mit (initialisierten) Zufallszahlen
    srand(0);
    start = system_clock::now();
    
    while (v2.size()<numbers)
    {
        int n = rand() % range;
        v2.set_value(n);
    }
    time2 = (double)(duration_cast<milliseconds>(system_clock::now()-start).count())/1000.0;

    cout << "      Zeit v2: " << time2 << endl;

    return (2*time2 < time1);
}
