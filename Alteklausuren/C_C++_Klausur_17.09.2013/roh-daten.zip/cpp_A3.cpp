// Prüfung C++, Herbst 2013, A.Voss@FH-Aachen.de

#include "test.h"
#include "ident.h"

// Ihr code 
#include "cpp_A3.hpp"

int main()
{   
    StartTest("C++",3);

    AssertS("'sum 1 thread'", sum(1));
    AssertS("'- 2 threads'",  sum(2));
    AssertS("'- 10 threads'", sum(10));

    StopTest();
    
    return EXIT_SUCCESS;
}
