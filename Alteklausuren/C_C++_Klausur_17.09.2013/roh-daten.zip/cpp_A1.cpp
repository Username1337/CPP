// Prüfung C++, Herbst 2013, A.Voss@FH-Aachen.de

#include "test.h"
#include "ident.h"

// Ihr code 
#include "cpp_A1.hpp"

int main()
{   
    StartTest("C++",1);

    AssertS("'ctor,cont.'", test_ctor_contains() );
    AssertS("'set/get'",    test_set_remove() );
    AssertS("'op+'",        test_opplus() );
    AssertS("'output'",     test_output() );
    AssertS("'speed'",      test_speed() );

    StopTest();
    
    return EXIT_SUCCESS;
}
