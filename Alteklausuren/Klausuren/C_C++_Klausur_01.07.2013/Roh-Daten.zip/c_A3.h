// Prüfung C, Sommer 2013, A.Voss@FH-Aachen.de

// todo: matse_name:   Nachname
// todo: matse_matrnr: 123456

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

// todo:
char * read_word(const char* FileSrc, unsigned int word_no)
{
    return NULL;
}
