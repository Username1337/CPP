// Prüfung C, Sommer 2013, A.Voss@FH-Aachen.de

#include <stdio.h>
#include <stdlib.h>
#include "test.h"
#include "ident.h"

// Ihr code 
#include "c_A1.h"

// test cases (tc) 
// Aufbau: Test-String, erwarteter Rückgabewert
const struct { char * candidat; int expected; } tc[] = { 
    { "",       1 }, 
    { "x",      1 }, 
    { "tt",     1 }, 
    { "xy",     0 },
    { "oto",    1 }, 
    { "otto",   1 }, 
    { "otp",    0 }, 
    { "ein esel lese nie",1 } 
};
const size_t tc_count = sizeof(tc)/sizeof(tc[0]);

int main()
{   
    StartTest("C",1);
    
    // alle Testfälle
    for (size_t i=0; i<tc_count; ++i) 
    {
        Assert1(i, tc[i].expected == is_palindrom(tc[i].candidat) );
    }
    
    StopTest();
    
    return EXIT_SUCCESS;
}
