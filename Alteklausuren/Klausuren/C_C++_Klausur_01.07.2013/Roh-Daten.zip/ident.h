// Prüfung C, Sommer 2013, A.Voss@FH-Aachen.de

const char * matse_name()   { return "Nachname"; }
const char * matse_matrnr() { return "123456"; }
