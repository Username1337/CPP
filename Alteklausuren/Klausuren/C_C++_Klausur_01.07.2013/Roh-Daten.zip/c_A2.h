// Prüfung C, Sommer 2013, A.Voss@FH-Aachen.de

// todo: matse_name:   Nachname
// todo: matse_matrnr: 123456

#include <stdio.h>
#include <string.h>

// todo:
void calc_histogram(const char * text, histogram_t** p, unsigned int * n)
{
}
