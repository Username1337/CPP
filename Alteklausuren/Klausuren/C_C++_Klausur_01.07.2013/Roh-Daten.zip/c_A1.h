// Prüfung C, Sommer 2013, A.Voss@FH-Aachen.de

// todo: matse_name:   Nachname
// todo: matse_matrnr: 123456

#include <stdio.h>
#include <string.h>

// todo:
int is_palindrom(char * p)
{
    return -1;
}

