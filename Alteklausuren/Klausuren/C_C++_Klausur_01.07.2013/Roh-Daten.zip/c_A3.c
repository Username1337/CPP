// Prüfung C, Sommer 2013, A.Voss@FH-Aachen.de

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "test.h"
#include "ident.h"

// Ihr code 
#include "c_A3.h"

// test cases (tc)
// Aufbau: Nr. des abgefragten Wortes, erwarteter Rückgabewert
const struct { unsigned int no; char * expected; } tc[] = {
    { 0, "Ein" },
    { 1, "Esel" },
    { 3, "nie." },
    { 4, "" },
}; 
const size_t tc_count = sizeof(tc)/sizeof(tc[0]);

int main()
{   
    StartTest("C",2);
    
    // alle Testfälle
    for (size_t i=0; i<tc_count; ++i) 
    {
        char * word = read_word("./c_A3.txt",tc[i].no);

        Assert1(i, (NULL!=word) && (0==strcmp(word,tc[i].expected)) );

        free(word);
    }
    
    StopTest();
    
    return EXIT_SUCCESS;
}
