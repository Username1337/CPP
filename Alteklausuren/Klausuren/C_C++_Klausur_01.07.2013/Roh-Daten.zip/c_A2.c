// Prüfung C, Sommer 2013, A.Voss@FH-Aachen.de

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "test.h"
#include "ident.h"

// Struktur für die Häufigkeit eines Zeichens
typedef struct { char c; unsigned int n; } histogram_t;

// Ihr code 
#include "c_A2.h"

// test cases (tc)
// Aufbau: Test-String für ein Histogramm (z.B. "Hallo"), 
//   Anzahl unterschiedlicher Zeichen (Bsp.4) und 
//   Feld von Einzelhäufigkeiten 
//   (Bsp. 'e' 1 mal, 'h' 1 mal, 'l' 2 mal, 'o' 1 mal)
//   alphab. sortiert 
const struct { char * text; unsigned int count; histogram_t expected[5]; } tc[] = {
    { "hello", 4, { {'e',1},{'h',1},{'l',2},{'o',1}, } },
    { "bbbbb", 1, { {'b',5} } },
    { "abcde", 5, { {'a',1},{'b',1},{'c',1},{'d',1},{'e',1}, } },
    { "", 0, { {'\0',0} } },
};
const size_t tc_count = sizeof(tc)/sizeof(tc[0]);

int main()
{   
    StartTest("C",2);
    
    // alle Testfälle
    for (size_t i=0; i<tc_count; ++i) 
    {
        histogram_t * p = NULL;
        unsigned int n = 0;

        calc_histogram(tc[i].text,&p,&n); 

        // stimmt die Anzahl?
        Assert2(i,0, tc[i].count == n); 
        if (NULL!=p) 
        {
            // stimmen die Einzelhäufigkeiten?
            for (unsigned int j=0; j<n; ++j)
                Assert2(i,j+1,(tc[i].expected[j].c==p[j].c && tc[i].expected[j].n==p[j].n));
            
            free(p);
        }
    }
        
    StopTest();
    
    return EXIT_SUCCESS;
}
